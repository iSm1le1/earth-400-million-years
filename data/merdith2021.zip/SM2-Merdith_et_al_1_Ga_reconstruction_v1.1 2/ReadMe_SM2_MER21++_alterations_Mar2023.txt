Alterations to 1 Ga plate model of Merdith++ 2021 (ESR)

Preamble

Some issues have been identified in the model where plate boundaries labelled 'transformed' had either a high convergence rate or high divergence rate. That is, even though they were labelled and conceptualised as transform boundaries (perhaps in some cases with an implied small amount of convergence or divergence motion), in the model they were clearly accommodation large amounts of crustal production or consumption. In the original intent of MER21++, the conceptualisation of plate boundaries was that plate motion moves orthogonally from a mid-ocean ridge towards a subduction zone (subduction does not have to be (sub)orthogonal). In a simple system, connecting a spreading ridge and subduction zone are a series of transform boundaries, (sub)parallel to the direction of movement:

—————————|>
||       |>
||       |>
——————   —|>
    ||    |>
    ||    |>
    ||    |>
    ——————|>

In this sense, reconstructing extinct ocean basins follows a simple procedure. Known subduction zones are mapped onto a continental motion model (e.g. as one defined from palaeomagnetic data), interpolation to connect regional subduction zones occurs. In ocean basins similar to the Atlantic or Indian oceans, mid-ocean ridges are inferred to be perpendicular to the direction of continental breakup (usually easiest when a supercontinent breaks up and clearly defined conjugate margins are preserved in the geological record). These mid-ocean ridges are typically easy to connect with subduction zones through a series of transform boundaries, much like the mid-Atlantic ridge connects through the Caribbean and Costa Rica with Pacific subduction, or through the Scotia-Sandiwch plates to Patagonia and the southern Pacific.

However, this approach does not work so well for large external ocean basins like the Pacific or Panthalassa Oceans, where there is a large ocean (>1/4 Earth surface) and a fragmentary record of subduction around the periphery. It is also compounded when the available data constraining plate motion of major cratons and continents are poor, as there are no constraints on both spreading rate and spreading direction. In these cases the approach of MER21++ (and also that of Domeier and Torsivk (2014) and Young et al. (2019)) is to ensure that at modelled mid-ocean ridges, divergence is occurring, and at known subduction zones, convergence is also occurring.

In this manner, the original MER21++ model mostly satisfied this constraint, however the model over-relied on transform boundaries to accommodate plate motion, such that many of the transform boundaries should be labelled (or considered) as 'inferred subduction zones'. Inferred, because the kinematic constraints of the constructed model (i.e. the location, orientation and spreading direction of synthetic mid-ocean ridges) require more subduction in order to accommodate a basic tenet of plate tectonic theory, that there is a balance of new crust created and destroyed over Ma timescales. In the original model, if one were to calculated total crustal production (spreading-ate • mid-ocean ridge length) and total crustal consumption (convergence rate • subduction zone length) they would not be equal.

Thus, the alterations offered in this update(?) pertain to either changing the labels of some transform boundaries that were identified to have a high convergence or divergence rate or to re-align these transform boundaries to better fit the small-circle orientation defined by the plate motion. We selected a convergence/divergence rate threshold of 2 cm/a as problematic (i.e. boundaries with rates higher than this were investigated) and also a plate boundary length greater than 500 km. The majority of these boundaries occurred in ocean basins away from large cratons, a few more major transform boundaries that were changed are identified below. Some oceanic plates had their plate velocity changed to either ensure that the revised boundaries were accommodated properly or mid-ocean ridge configuration altered (summarised below). No continental plate motion was changed. The majority of the changes occurred in the Neoproterozoic, until around 600 Ma, though a few boundaries were also changed in the Palaeozoic.

These changes have resulted in bringing gross crustal production and consumption curves into much better (but still not perfect) agreement. Pragmatically, the subduction zones in the original (published) model are a stronger reflection of subduction that is preserved (and conservatively interpolated, as one might interpolate subduction along the Andean margin through amagmatic regions) in the geological record, while this altered model also contains inferred subduction zones, as necessitated by our mid-ocean spreading ridges. The difference therefore is either a reflection of arcs (principally oceanic) that are lost to time, or some idea of the inherent uncertainty within making full-plate models in deep-time (i.e. how much more unknown subduction do we need to account for kinematically balancing global plate motion).

Major boundary changes

Mawson sea-spreading removed (1000–940 Ma)
Boundary separating Tarim from Mawson-sea simplified to a single transform boundary, one arm of the Mirovoi MOR triple junction was re-aligned (directly intersecting subduction outboard of Siberia) (1000–900 Ma)
Realigned transform boundaries in Mawson Sea (940–900 Ma)
Subduction outboard of Indo-Antarctica has been removed from 900–870 Ma (still present 870–850 Ma). In the original model this was inferred subduction based on plate motion and some sparse evidence of reactivated faults after Ruker collided with the Eastern Ghats-Raynor (NB could still work if a new ocean plate introduced).
Transform boundary connecting Mirovoi MOR with Tarim replaced with a MOR boundary to make a proper triple junction (900-800 Ma)
Ocean plate subdbucting under India simplified to a one plate system (850–800 Ma)
Transform outboard of Kalarhai Craton replaced with subduction zone (800-750 Ma)
Ocean plate subducting under India separated into a 'Tarim plate' and 'Ocean plate under India' (800-750 Ma)
Mirovoi triple junction extended to 750 Ma
Transform changed to subduction zone outboard of WAC (750-700 Ma)
Cadomia-Avalonia subduction extended eastward past SM into the ocean (600–580 Ma)
The long transform outboard of Baltica as the Iapetus opened is now an oceanic subduction zone (probably the most significant change) (585–520 Ma)
Tranform outboard of western Laurentian margin now a subduction zone (500-450 Ma)
A duplicate subduction zone between 760 and 751 has been removed

Ocean plate velocity changes

Mirovoi ocean plate subjecting under Siberia has velocity increased slightly (900-850 Ma)
Mawson sea velocity changed to ensure convergence under Australia (1000-850 Ma)